// 🎣 Deep Sea Fishing Adventure - Game Logic
// Public Release v1.0

// ========================================
// SOUND SYSTEM
// ========================================

const SoundSystem = {
    enabled: true,
    volume: 0.5,
    
    // Web Audio API context
    audioContext: null,
    
    // Initialize audio context
    init() {
        try {
            this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
            console.log('Sound system initialized!');
        } catch (e) {
            console.warn('Web Audio API not supported:', e);
            this.enabled = false;
        }
    },
    
    // Play casting sound
    playCast() {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        // Whoosh sound
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(800, ctx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(200, ctx.currentTime + 0.3);
        
        gainNode.gain.setValueAtTime(this.volume * 0.3, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
        
        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.3);
    },
    
    // Play reeling sound (continuous while fishing)
    playReeling(duration) {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        const clickCount = Math.floor(duration / 100); // Click every 100ms
        
        for (let i = 0; i < clickCount; i++) {
            setTimeout(() => {
                this.playReelClick();
            }, i * 100);
        }
    },
    
    // Single reel click sound
    playReelClick() {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();
        const filter = ctx.createBiquadFilter();
        
        oscillator.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        // Mechanical click sound
        oscillator.type = 'square';
        oscillator.frequency.setValueAtTime(150, ctx.currentTime);
        
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(300, ctx.currentTime);
        
        gainNode.gain.setValueAtTime(this.volume * 0.15, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.05);
        
        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.05);
    },
    
    // Play splash sound
    playSplash() {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        const bufferSize = ctx.sampleRate * 0.5;
        const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const data = buffer.getChannelData(0);
        
        // Generate noise for splash
        for (let i = 0; i < bufferSize; i++) {
            data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.1));
        }
        
        const source = ctx.createBufferSource();
        const gainNode = ctx.createGain();
        const filter = ctx.createBiquadFilter();
        
        source.buffer = buffer;
        source.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(800, ctx.currentTime);
        filter.frequency.exponentialRampToValueAtTime(100, ctx.currentTime + 0.3);
        
        gainNode.gain.setValueAtTime(this.volume * 0.4, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
        
        source.start(ctx.currentTime);
    },
    
    // Play catch success sound
    playCatch(rarity) {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        
        // Different sounds for different rarities
        const rarityFreqs = {
            common: [400, 500],
            uncommon: [500, 650],
            rare: [600, 800],
            epic: [700, 950],
            legendary: [800, 1200],
            divine: [900, 1400],
            secret: [1000, 1600]
        };
        
        const [startFreq, endFreq] = rarityFreqs[rarity] || rarityFreqs.common;
        
        // Triumphant chord
        for (let i = 0; i < 3; i++) {
            setTimeout(() => {
                const oscillator = ctx.createOscillator();
                const gainNode = ctx.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(ctx.destination);
                
                oscillator.type = 'sine';
                oscillator.frequency.setValueAtTime(startFreq * (1 + i * 0.25), ctx.currentTime);
                oscillator.frequency.exponentialRampToValueAtTime(endFreq * (1 + i * 0.25), ctx.currentTime + 0.3);
                
                gainNode.gain.setValueAtTime(this.volume * 0.2, ctx.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
                
                oscillator.start(ctx.currentTime);
                oscillator.stop(ctx.currentTime + 0.3);
            }, i * 50);
        }
        
        // Extra sparkle for rare catches
        if (['epic', 'legendary', 'divine', 'secret'].includes(rarity)) {
            setTimeout(() => this.playSparkle(), 200);
        }
    },
    
    // Play sparkle sound for rare catches
    playSparkle() {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        
        for (let i = 0; i < 5; i++) {
            setTimeout(() => {
                const oscillator = ctx.createOscillator();
                const gainNode = ctx.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(ctx.destination);
                
                oscillator.type = 'sine';
                oscillator.frequency.setValueAtTime(1200 + Math.random() * 800, ctx.currentTime);
                
                gainNode.gain.setValueAtTime(this.volume * 0.1, ctx.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
                
                oscillator.start(ctx.currentTime);
                oscillator.stop(ctx.currentTime + 0.2);
            }, i * 80);
        }
    },
    
    // Play level up sound
    playLevelUp() {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        
        // Victory fanfare
        const notes = [523, 659, 784, 1047]; // C, E, G, C (major chord)
        
        notes.forEach((freq, i) => {
            setTimeout(() => {
                const oscillator = ctx.createOscillator();
                const gainNode = ctx.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(ctx.destination);
                
                oscillator.type = 'triangle';
                oscillator.frequency.setValueAtTime(freq, ctx.currentTime);
                
                gainNode.gain.setValueAtTime(this.volume * 0.3, ctx.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
                
                oscillator.start(ctx.currentTime);
                oscillator.stop(ctx.currentTime + 0.5);
            }, i * 100);
        });
    },
    
    // Play coin sound
    playCoin() {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(1000, ctx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(1500, ctx.currentTime + 0.1);
        
        gainNode.gain.setValueAtTime(this.volume * 0.2, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
        
        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.1);
    },
    
    // Mini-game sounds
    playGaryBite() {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        
        // Aggressive bite sound - quick attack
        for (let i = 0; i < 3; i++) {
            setTimeout(() => {
                const oscillator = ctx.createOscillator();
                const gainNode = ctx.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(ctx.destination);
                
                oscillator.type = 'sawtooth';
                oscillator.frequency.setValueAtTime(150 - i * 20, ctx.currentTime);
                oscillator.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.1);
                
                gainNode.gain.setValueAtTime(this.volume * 0.3, ctx.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
                
                oscillator.start(ctx.currentTime);
                oscillator.stop(ctx.currentTime + 0.1);
            }, i * 40);
        }
    },
    
    playGaryMove() {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();
        const filter = ctx.createBiquadFilter();
        
        oscillator.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        // Subtle swoosh as Gary moves
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(200, ctx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(150, ctx.currentTime + 0.15);
        
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(400, ctx.currentTime);
        
        gainNode.gain.setValueAtTime(this.volume * 0.08, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
        
        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.15);
    },
    
    playLineMove() {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        // Quick click for line movement
        oscillator.type = 'square';
        oscillator.frequency.setValueAtTime(300, ctx.currentTime);
        
        gainNode.gain.setValueAtTime(this.volume * 0.12, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.03);
        
        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.03);
    },
    
    playCaptureIncrease() {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        // Rising pitch for progress increase
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(400, ctx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(500, ctx.currentTime + 0.08);
        
        gainNode.gain.setValueAtTime(this.volume * 0.15, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.08);
        
        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.08);
    },
    
    playCaptureDecrease() {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        // Falling pitch for progress decrease
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(350, ctx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(250, ctx.currentTime + 0.1);
        
        gainNode.gain.setValueAtTime(this.volume * 0.12, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
        
        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.1);
    },
    
    playMinigameSuccess() {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        
        // Victory jingle - 4 note ascending scale
        const notes = [523, 659, 784, 1047]; // C, E, G, high C
        
        notes.forEach((freq, i) => {
            setTimeout(() => {
                const oscillator = ctx.createOscillator();
                const gainNode = ctx.createGain();
                
                oscillator.connect(gainNode);
                gainNode.connect(ctx.destination);
                
                oscillator.type = 'sine';
                oscillator.frequency.setValueAtTime(freq, ctx.currentTime);
                
                gainNode.gain.setValueAtTime(this.volume * 0.25, ctx.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
                
                oscillator.start(ctx.currentTime);
                oscillator.stop(ctx.currentTime + 0.3);
            }, i * 100);
        });
    },
    
    playMinigameReelTension() {
        if (!this.enabled || !this.audioContext) return;
        
        const ctx = this.audioContext;
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        // Tension sound - low continuous tone
        oscillator.type = 'sawtooth';
        oscillator.frequency.setValueAtTime(100, ctx.currentTime);
        
        gainNode.gain.setValueAtTime(this.volume * 0.1, ctx.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.2);
        
        oscillator.start(ctx.currentTime);
        oscillator.stop(ctx.currentTime + 0.2);
    },
    
    // Toggle sound on/off
    toggle() {
        this.enabled = !this.enabled;
        return this.enabled;
    },
    
    // Set volume (0-1)
    setVolume(vol) {
        this.volume = Math.max(0, Math.min(1, vol));
    }
};

// ========================================
// MINI-GAME SYSTEM
// ========================================

const MiniGame = {
    active: false,
    linePosition: 250, // Starting position of green line (center)
    garyPosition: 300, // Starting position of Gary
    captureProgress: 0,
    maxProgress: 100,
    containerWidth: 520, // Width of reel container (minus padding)
    lineWidth: 80,
    garyWidth: 60,
    moveSpeed: 8, // Pixels per move
    garyMoveSpeed: 2, // Gary moves slower
    garyDirection: 1, // 1 for right, -1 for left
    updateInterval: null,
    startTime: 0,
    currentFish: null,
    wasCapturing: false, // Track state for sound changes
    lastGaryDirection: 1, // Track when Gary changes direction
    soundThrottle: {
        garyMove: 0,
        captureIncrease: 0,
        captureDecrease: 0,
        reelTension: 0
    },
    
    // Difficulty settings based on rarity
    raritySettings: {
        common: { garySpeed: 1.5, captureRate: 2, depleteRate: 1, threshold: 50 },
        uncommon: { garySpeed: 2, captureRate: 1.8, depleteRate: 1.2, threshold: 45 },
        rare: { garySpeed: 2.5, captureRate: 1.5, depleteRate: 1.5, threshold: 40 },
        epic: { garySpeed: 3, captureRate: 1.2, depleteRate: 1.8, threshold: 35 },
        legendary: { garySpeed: 3.5, captureRate: 1, depleteRate: 2, threshold: 30 },
        divine: { garySpeed: 4, captureRate: 0.8, depleteRate: 2.5, threshold: 25 },
        secret: { garySpeed: 5, captureRate: 0.5, depleteRate: 3, threshold: 20 }
    },
    
    start(fish) {
        this.active = true;
        this.currentFish = fish;
        this.linePosition = this.containerWidth / 2 - this.lineWidth / 2;
        this.garyPosition = this.containerWidth / 2 - this.garyWidth / 2;
        this.captureProgress = 0;
        this.garyDirection = Math.random() > 0.5 ? 1 : -1;
        this.lastGaryDirection = this.garyDirection;
        this.startTime = Date.now();
        this.wasCapturing = false;
        
        // Reset sound throttles
        this.soundThrottle = {
            garyMove: 0,
            captureIncrease: 0,
            captureDecrease: 0,
            reelTension: 0
        };
        
        // Get difficulty settings
        const settings = this.raritySettings[fish.rarity] || this.raritySettings.common;
        this.garyMoveSpeed = settings.garySpeed;
        
        // Show mini-game overlay
        document.getElementById('minigameOverlay').classList.add('active');
        document.getElementById('rarityDisplay').textContent = fish.rarity.toUpperCase();
        document.getElementById('rarityDisplay').style.color = this.getRarityColor(fish.rarity);
        
        // Initialize positions
        this.updatePositions();
        
        // Play bite sound
        SoundSystem.playGaryBite();
        
        // Start game loop
        this.updateInterval = setInterval(() => this.update(), 50); // 20 FPS
        
        addMessage(`🎮 Mini-game started! Catch the ${fish.rarity} ${fish.name}!`);
    },
    
    update() {
        if (!this.active) return;
        
        const now = Date.now();
        
        // Move Gary (the fish)
        this.garyPosition += this.garyDirection * this.garyMoveSpeed;
        
        // Bounce Gary off walls
        if (this.garyPosition <= 0) {
            this.garyPosition = 0;
            this.garyDirection = 1;
            
            // Play Gary move sound when changing direction
            if (this.lastGaryDirection !== this.garyDirection) {
                SoundSystem.playGaryMove();
                this.lastGaryDirection = this.garyDirection;
            }
        } else if (this.garyPosition >= this.containerWidth - this.garyWidth) {
            this.garyPosition = this.containerWidth - this.garyWidth;
            this.garyDirection = -1;
            
            // Play Gary move sound when changing direction
            if (this.lastGaryDirection !== this.garyDirection) {
                SoundSystem.playGaryMove();
                this.lastGaryDirection = this.garyDirection;
            }
        }
        
        // Occasional Gary move sound (throttled to every 500ms)
        if (now - this.soundThrottle.garyMove > 500) {
            if (Math.random() < 0.3) { // 30% chance per check
                SoundSystem.playGaryMove();
                this.soundThrottle.garyMove = now;
            }
        }
        
        // Calculate distance between line center and Gary center
        const lineCenter = this.linePosition + this.lineWidth / 2;
        const garyCenter = this.garyPosition + this.garyWidth / 2;
        const distance = Math.abs(lineCenter - garyCenter);
        
        // Get difficulty settings
        const settings = this.raritySettings[this.currentFish.rarity] || this.raritySettings.common;
        
        // Check if we're capturing
        const isCapturing = distance < settings.threshold;
        
        // Update capture progress based on distance
        if (isCapturing) {
            // Good! Line is on Gary
            this.captureProgress += settings.captureRate;
            
            // Play capture increase sound (throttled to every 200ms)
            if (now - this.soundThrottle.captureIncrease > 200) {
                SoundSystem.playCaptureIncrease();
                this.soundThrottle.captureIncrease = now;
            }
            
            // State changed to capturing
            if (!this.wasCapturing) {
                this.wasCapturing = true;
            }
        } else {
            // Bad! Line is not on Gary
            this.captureProgress -= settings.depleteRate;
            
            // Play capture decrease sound (throttled to every 300ms)
            if (now - this.soundThrottle.captureDecrease > 300) {
                SoundSystem.playCaptureDecrease();
                this.soundThrottle.captureDecrease = now;
            }
            
            // Play tension sound occasionally when not capturing (throttled to every 400ms)
            if (now - this.soundThrottle.reelTension > 400) {
                if (Math.random() < 0.4) {
                    SoundSystem.playMinigameReelTension();
                    this.soundThrottle.reelTension = now;
                }
            }
            
            // State changed to not capturing
            if (this.wasCapturing) {
                this.wasCapturing = false;
            }
        }
        
        // Clamp progress
        this.captureProgress = Math.max(0, Math.min(this.maxProgress, this.captureProgress));
        
        // Update UI
        this.updateUI(distance, isCapturing);
        
        // Check win condition
        if (this.captureProgress >= this.maxProgress) {
            this.win();
        }
    },
    
    updateUI(distance, isCapturing) {
        // Update positions
        this.updatePositions();
        
        // Update progress bar
        const progressPercent = (this.captureProgress / this.maxProgress * 100).toFixed(1);
        document.getElementById('captureProgressFill').style.width = progressPercent + '%';
        document.getElementById('captureProgressFill').textContent = Math.floor(progressPercent) + '%';
        document.getElementById('capturePercent').textContent = Math.floor(progressPercent) + '%';
        
        // Update distance display with color coding
        const distanceDisplay = document.getElementById('distanceDisplay');
        const settings = this.raritySettings[this.currentFish.rarity] || this.raritySettings.common;
        
        distanceDisplay.textContent = Math.floor(distance) + 'px';
        distanceDisplay.className = 'value';
        
        if (distance < settings.threshold) {
            distanceDisplay.classList.add('distance-good');
        } else if (distance < settings.threshold * 2) {
            distanceDisplay.classList.add('distance-medium');
        } else {
            distanceDisplay.classList.add('distance-bad');
        }
        
        // Update time
        const elapsed = ((Date.now() - this.startTime) / 1000).toFixed(1);
        document.getElementById('timeDisplay').textContent = elapsed + 's';
        
        // Visual feedback - make Gary struggle more when being captured
        const garyElement = document.getElementById('garyFish');
        if (isCapturing) {
            if (!garyElement.classList.contains('struggling')) {
                garyElement.classList.add('struggling');
            }
        } else {
            garyElement.classList.remove('struggling');
        }
    },
    
    updatePositions() {
        document.getElementById('reelLine').style.left = this.linePosition + 'px';
        document.getElementById('garyFish').style.left = this.garyPosition + 'px';
    },
    
    moveLeft() {
        if (!this.active) return;
        this.linePosition = Math.max(0, this.linePosition - this.moveSpeed);
        this.updatePositions();
        SoundSystem.playLineMove();
    },
    
    moveRight() {
        if (!this.active) return;
        this.linePosition = Math.min(this.containerWidth - this.lineWidth, this.linePosition + this.moveSpeed);
        this.updatePositions();
        SoundSystem.playLineMove();
    },
    
    win() {
        this.active = false;
        clearInterval(this.updateInterval);
        
        // Play success sound
        SoundSystem.playMinigameSuccess();
        
        // Hide overlay after a short delay
        setTimeout(() => {
            document.getElementById('minigameOverlay').classList.remove('active');
        }, 400);
        
        // Add fish to inventory
        gameState.inventory.push(this.currentFish);
        gameState.player.fishCaught++;
        
        // Play rarity-specific catch sound
        setTimeout(() => {
            SoundSystem.playCatch(this.currentFish.rarity);
        }, 500);
        
        if (!gameState.discoveredFish.has(this.currentFish.name)) {
            gameState.discoveredFish.add(this.currentFish.name);
            gameState.player.fishDiscovered++;
            addMessage(`📖 New fish discovered: ${this.currentFish.name}!`);
            setTimeout(() => {
                SoundSystem.playSparkle();
            }, 700);
        }
        
        const elapsed = ((Date.now() - this.startTime) / 1000).toFixed(1);
        addMessage(`🎉 You caught a ${this.currentFish.rarity.toUpperCase()} ${this.currentFish.name} (${this.currentFish.weight}kg) in ${elapsed}s! +${this.currentFish.xp} XP`);
        
        // Add XP
        gainXP(this.currentFish.xp);
        
        // Update quest progress
        updateQuestProgress(this.currentFish);
        
        // Update UI
        updateInventoryUI();
        updateStatsUI();
        
        // Re-enable fishing button
        const castButton = document.getElementById('castButton');
        castButton.disabled = false;
        castButton.textContent = "🎣 CAST LINE";
        gameState.isFishing = false;
    },
    
    getRarityColor(rarity) {
        const colors = {
            common: '#9ca3af',
            uncommon: '#60a5fa',
            rare: '#a78bfa',
            epic: '#fb923c',
            legendary: '#fbbf24',
            divine: '#f0abfc',
            secret: '#fff'
        };
        return colors[rarity] || '#fff';
    }
};

// Mini-game controls
function moveLineLeft() {
    MiniGame.moveLeft();
}

function moveLineRight() {
    MiniGame.moveRight();
}

// Keyboard controls for mini-game with hold support
let keyHoldInterval = null;
let keysHeld = {
    left: false,
    right: false
};

document.addEventListener('keydown', (e) => {
    if (!MiniGame.active) return;
    
    if ((e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') && !keysHeld.left) {
        e.preventDefault();
        keysHeld.left = true;
        MiniGame.moveLeft();
        
        if (!keyHoldInterval) {
            keyHoldInterval = setInterval(() => {
                if (keysHeld.left) MiniGame.moveLeft();
                if (keysHeld.right) MiniGame.moveRight();
            }, 50);
        }
    } else if ((e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') && !keysHeld.right) {
        e.preventDefault();
        keysHeld.right = true;
        MiniGame.moveRight();
        
        if (!keyHoldInterval) {
            keyHoldInterval = setInterval(() => {
                if (keysHeld.left) MiniGame.moveLeft();
                if (keysHeld.right) MiniGame.moveRight();
            }, 50);
        }
    }
});

document.addEventListener('keyup', (e) => {
    if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        keysHeld.left = false;
    } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        keysHeld.right = false;
    }
    
    if (!keysHeld.left && !keysHeld.right && keyHoldInterval) {
        clearInterval(keyHoldInterval);
        keyHoldInterval = null;
    }
});

// ========================================
// GAME STATE
// ========================================

let gameState = {
    player: {
        level: 1,
        xp: 0,
        xpRequired: 100,
        gold: 50,
        health: 100,
        maxHealth: 100,
        oxygen: 100,
        maxOxygen: 100,
        location: "Starter Island",
        currentIsland: "starterisland",
        rod: "Rusty Rod",
        rodStats: { luck: 0, speed: 1.0, vibration: "none" },
        boat: "None",
        boatSpeed: 0,
        fishCaught: 0,
        fishDiscovered: 0,
        deaths: 0,
        totalCasts: 0
    },
    inventory: [],
    hiredFishermen: [],
    maxFishermen: 5,
    dailyQuests: {
        streak: 0,
        lastCompleted: null,
        quest1: { progress: 0, required: 5, completed: false },
        quest2: { progress: 0, required: 3, completed: false }
    },
    discoveredFish: new Set(),
    lastSaveTime: Date.now(),
    isFishing: false,
    underwater: false
};

// ========================================
// FISH DATABASE (500 species)
// ========================================

const FISH_DATABASE = {
    common: [
        "Sardine", "Mackerel", "Herring", "Anchovy", "Minnow", "Carp", "Perch", "Sunfish",
        "Bass", "Trout", "Catfish", "Pike", "Chub", "Dace", "Roach", "Bream",
        "Tench", "Rudd", "Bleak", "Gudgeon", "Loach", "Eel", "Lamprey", "Bullhead",
        "Stickleback", "Goby", "Blenny", "Wrasse", "Mullet", "Flounder"
    ],
    uncommon: [
        "Salmon", "Sea Bass", "Cod", "Haddock", "Pollock", "Whiting", "Plaice", "Sole",
        "Turbot", "Halibut", "Monkfish", "Grouper", "Snapper", "Barracuda", "Wahoo",
        "Kingfish", "Amberjack", "Pompano", "Permit", "Bonefish", "Tarpon", "Cobia"
    ],
    rare: [
        "Swordfish", "Tuna", "Mahi-Mahi", "Marlin", "Sailfish", "Spearfish", "Dorado",
        "Yellowfin", "Bluefin", "Albacore", "Skipjack", "Bonito", "Mackerel King",
        "Giant Grouper", "Goliath Grouper", "Dragon Wrasse", "Emperor Fish"
    ],
    epic: [
        "Giant Squid", "Hammerhead Shark", "Tiger Shark", "Bull Shark", "Great White Shark",
        "Whale Shark", "Manta Ray", "Eagle Ray", "Sawfish", "Sturgeon", "Arapaima",
        "Giant Catfish", "Alligator Gar", "Beluga Sturgeon", "Paddlefish"
    ],
    legendary: [
        "Megalodon", "Kraken", "Leviathan", "Sea Serpent", "Ancient Marlin",
        "Colossal Squid", "Giant Oarfish", "Prehistoric Coelacanth", "Mythic Tuna",
        "Titan Grouper", "Emperor Swordfish"
    ],
    divine: [
        "Phoenix Bass", "Celestial Whale", "Stardust Ray", "Cosmic Tuna",
        "Ethereal Marlin", "Divine Koi", "Angelic Salmon", "Holy Mackerel",
        "Blessed Swordfish", "Sacred Grouper"
    ],
    secret: [
        "The Forbidden Catch", "Void Serpent", "Time Eater", "Paradox Fish",
        "The Final Mystery"
    ]
};

// ========================================
// RARITY CHANCES
// ========================================

function getRarityChances() {
    const baseLuck = gameState.player.rodStats.luck;
    return {
        common: Math.max(5, 65 - baseLuck),
        uncommon: 22 + (baseLuck * 0.2),
        rare: 9 + (baseLuck * 0.3),
        epic: 3 + (baseLuck * 0.2),
        legendary: 0.9 + (baseLuck * 0.15),
        divine: 0.09 + (baseLuck * 0.1),
        secret: 0.01 + (baseLuck * 0.05)
    };
}

// ========================================
// FISH GENERATION
// ========================================

function catchFish() {
    const chances = getRarityChances();
    const roll = Math.random() * 100;
    
    let rarity;
    let cumulative = 0;
    
    for (const [rarityType, chance] of Object.entries(chances)) {
        cumulative += chance;
        if (roll <= cumulative) {
            rarity = rarityType;
            break;
        }
    }
    
    if (!rarity) rarity = "common";
    
    const fishList = FISH_DATABASE[rarity];
    const fishName = fishList[Math.floor(Math.random() * fishList.length)];
    const weight = (Math.random() * 50 + 1).toFixed(2);
    
    // Calculate XP and Gold based on rarity
    const xpValues = { common: 5, uncommon: 15, rare: 40, epic: 100, legendary: 300, divine: 1000, secret: 5000 };
    const goldValues = { common: 2, uncommon: 10, rare: 30, epic: 100, legendary: 500, divine: 3000, secret: 25000 };
    
    const xp = xpValues[rarity] * (1 + Math.random() * 0.5);
    const goldValue = goldValues[rarity] + Math.floor(Math.random() * goldValues[rarity]);
    
    const fish = {
        name: fishName,
        rarity: rarity,
        weight: weight,
        xp: Math.floor(xp),
        value: goldValue,
        caughtAt: Date.now()
    };
    
    return fish;
}

// ========================================
// FISHING ACTION
// ========================================

function castLine() {
    if (gameState.isFishing) {
        addMessage("⏳ You're already fishing! Wait for the line to settle...");
        return;
    }
    
    gameState.isFishing = true;
    gameState.player.totalCasts++;
    
    const castButton = document.getElementById('castButton');
    castButton.disabled = true;
    castButton.textContent = "🎣 Fishing...";
    
    // Play casting sound
    SoundSystem.playCast();
    
    addMessage("🎣 You cast your line into the water...");
    
    // Fishing takes 1-3 seconds (modified by rod speed)
    const baseTime = (Math.random() * 2000 + 1000) / gameState.player.rodStats.speed;
    
    // Play splash sound
    setTimeout(() => {
        SoundSystem.playSplash();
    }, 300);
    
    // Start reeling sound
    setTimeout(() => {
        SoundSystem.playReeling(baseTime - 500);
    }, 500);
    
    // Animate fishing canvas
    animateFishing();
    
    setTimeout(() => {
        // Generate the fish
        const fish = catchFish();
        
        // Start mini-game instead of auto-catching
        addMessage("🐟 A fish bit the line! Reel it in!");
        MiniGame.start(fish);
        
    }, baseTime);
}

// ========================================
// XP AND LEVELING
// ========================================

function gainXP(amount) {
    gameState.player.xp += amount;
    
    while (gameState.player.xp >= gameState.player.xpRequired) {
        levelUp();
    }
    
    updateStatsUI();
}

function levelUp() {
    gameState.player.xp -= gameState.player.xpRequired;
    gameState.player.level++;
    
    // Play level up sound
    SoundSystem.playLevelUp();
    
    // Calculate new XP requirement (progressive scaling)
    if (gameState.player.level <= 100) {
        gameState.player.xpRequired = Math.floor(100 * Math.pow(gameState.player.level, 1.5));
    } else if (gameState.player.level <= 500) {
        gameState.player.xpRequired = Math.floor(100000 + (gameState.player.level - 100) * 1000);
    } else if (gameState.player.level <= 1000) {
        gameState.player.xpRequired = Math.floor(2500000 + (gameState.player.level - 500) * 15000);
    } else {
        gameState.player.xpRequired = Math.floor(10000000 + (gameState.player.level - 1000) * 30000);
    }
    
    // Level up bonuses
    gameState.player.maxHealth += 10;
    gameState.player.health = gameState.player.maxHealth;
    gameState.player.maxOxygen += 5;
    gameState.player.oxygen = gameState.player.maxOxygen;
    
    const goldReward = gameState.player.level * 10;
    gameState.player.gold += goldReward;
    
    addMessage(`🎊 LEVEL UP! You are now level ${gameState.player.level}! +${goldReward}g`);
    
    // Check for milestone rewards
    checkMilestones();
    
    updateStatsUI();
}

function checkMilestones() {
    const level = gameState.player.level;
    
    if (level === 10) {
        addMessage("🏆 Milestone reached! You've unlocked new features!");
        gameState.player.gold += 500;
    } else if (level === 25) {
        addMessage("🏆 Level 25 Milestone! +2500g bonus!");
        gameState.player.gold += 2500;
    } else if (level === 50) {
        addMessage("🏆 Level 50 Milestone! Master Angler title earned!");
        gameState.player.gold += 10000;
    } else if (level === 100) {
        addMessage("🏆 LEVEL 100! Legendary Fisher! +50,000g!");
        gameState.player.gold += 50000;
    }
}

// ========================================
// QUEST SYSTEM
// ========================================

function updateQuestProgress(fish) {
    // Quest 1: Catch 5 fish
    if (!gameState.dailyQuests.quest1.completed) {
        gameState.dailyQuests.quest1.progress++;
        if (gameState.dailyQuests.quest1.progress >= gameState.dailyQuests.quest1.required) {
            completeQuest(1);
        }
    }
    
    // Quest 2: Catch 3 Uncommon or better
    if (!gameState.dailyQuests.quest2.completed && fish.rarity !== 'common') {
        gameState.dailyQuests.quest2.progress++;
        if (gameState.dailyQuests.quest2.progress >= gameState.dailyQuests.quest2.required) {
            completeQuest(2);
        }
    }
    
    updateQuestUI();
}

function completeQuest(questNum) {
    const quest = gameState.dailyQuests[`quest${questNum}`];
    quest.completed = true;
    
    if (questNum === 1) {
        gainXP(50);
        gameState.player.gold += 25;
        addMessage("✅ Quest Complete! Beginner's Luck - +50 XP, +25g");
    } else if (questNum === 2) {
        gainXP(100);
        gameState.player.gold += 50;
        addMessage("✅ Quest Complete! Uncommon Hunter - +100 XP, +50g");
    }
    
    // Check if all dailies complete
    if (gameState.dailyQuests.quest1.completed && gameState.dailyQuests.quest2.completed) {
        gameState.dailyQuests.streak++;
        addMessage(`🔥 All daily quests complete! Streak: ${gameState.dailyQuests.streak} days!`);
    }
}

// ========================================
// SOUND CONTROLS
// ========================================

function toggleSound() {
    const enabled = SoundSystem.toggle();
    const btn = document.getElementById('soundToggle');
    btn.textContent = enabled ? '🔊 Sound ON' : '🔇 Sound OFF';
    
    if (enabled && !SoundSystem.audioContext) {
        SoundSystem.init();
    }
}

function setVolume(value) {
    SoundSystem.setVolume(value / 100);
    document.getElementById('volumeLabel').textContent = value + '%';
}

// ========================================
// FISHING ANIMATION
// ========================================

function animateFishing() {
    const canvas = document.getElementById('fishingCanvas');
    const ctx = canvas.getContext('2d');
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw water
    ctx.fillStyle = 'rgba(30, 60, 114, 0.8)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Draw waves
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.lineWidth = 2;
    for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.moveTo(0, 100 + i * 80);
        for (let x = 0; x < canvas.width; x += 20) {
            ctx.lineTo(x, 100 + i * 80 + Math.sin((x + Date.now() * 0.002) * 0.02) * 10);
        }
        ctx.stroke();
    }
    
    // Draw fishing line
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(canvas.width / 2, 50);
    ctx.lineTo(canvas.width / 2 + Math.sin(Date.now() * 0.001) * 20, 300);
    ctx.stroke();
    
    // Draw bobber
    ctx.fillStyle = '#ff0000';
    ctx.beginPath();
    ctx.arc(canvas.width / 2 + Math.sin(Date.now() * 0.001) * 20, 300 + Math.sin(Date.now() * 0.005) * 10, 8, 0, Math.PI * 2);
    ctx.fill();
    
    if (gameState.isFishing) {
        requestAnimationFrame(animateFishing);
    }
}

// ========================================
// SELLING FISH
// ========================================

function sellAllFish() {
    if (gameState.inventory.length === 0) {
        addMessage("❌ No fish to sell!");
        return;
    }
    
    let totalGold = 0;
    gameState.inventory.forEach(fish => {
        totalGold += fish.value;
    });
    
    const fishCount = gameState.inventory.length;
    gameState.player.gold += totalGold;
    gameState.inventory = [];
    
    // Play coin sounds
    for (let i = 0; i < Math.min(fishCount, 10); i++) {
        setTimeout(() => {
            SoundSystem.playCoin();
        }, i * 50);
    }
    
    addMessage(`💰 Sold ${fishCount} fish for ${totalGold}g!`);
    updateInventoryUI();
    updateStatsUI();
}

// ========================================
// UI UPDATES
// ========================================

function updateStatsUI() {
    document.getElementById('playerLevel').textContent = `${gameState.player.level} / 4000`;
    document.getElementById('playerGold').textContent = `${gameState.player.gold}g`;
    document.getElementById('playerHealth').textContent = `${gameState.player.health}/${gameState.player.maxHealth} ❤️`;
    document.getElementById('playerOxygen').textContent = `${gameState.player.oxygen}/${gameState.player.maxOxygen} 💨`;
    document.getElementById('playerLocation').textContent = gameState.player.location;
    document.getElementById('currentRod').textContent = gameState.player.rod;
    document.getElementById('currentBoat').textContent = gameState.player.boat;
    document.getElementById('hiredCount').textContent = `${gameState.hiredFishermen.length}/${gameState.maxFishermen}`;
    document.getElementById('questStreak').textContent = `${gameState.dailyQuests.streak} days 🔥`;
    document.getElementById('fishCaught').textContent = gameState.player.fishCaught;
    document.getElementById('fishDiscovered').textContent = `${gameState.player.fishDiscovered}/500`;
    
    // Update XP bar
    const xpPercent = (gameState.player.xp / gameState.player.xpRequired) * 100;
    const xpBar = document.getElementById('xpBar');
    xpBar.style.width = `${xpPercent}%`;
    xpBar.textContent = `${gameState.player.xp}/${gameState.player.xpRequired} XP`;
    
    // Update health bar
    const healthPercent = (gameState.player.health / gameState.player.maxHealth) * 100;
    document.getElementById('healthBar').style.width = `${healthPercent}%`;
    
    // Update oxygen bar
    const oxygenPercent = (gameState.player.oxygen / gameState.player.maxOxygen) * 100;
    document.getElementById('oxygenBar').style.width = `${oxygenPercent}%`;
}

function updateInventoryUI() {
    const inventoryGrid = document.getElementById('inventoryGrid');
    
    if (gameState.inventory.length === 0) {
        inventoryGrid.innerHTML = '<p style="text-align: center; opacity: 0.6;">No fish caught yet...</p>';
        return;
    }
    
    inventoryGrid.innerHTML = '';
    gameState.inventory.forEach((fish, index) => {
        const fishCard = document.createElement('div');
        fishCard.className = `fish-card rarity-${fish.rarity}`;
        fishCard.innerHTML = `
            <div style="font-size: 2em;">🐟</div>
            <div style="font-weight: bold; margin: 5px 0;">${fish.name}</div>
            <div style="font-size: 0.85em; opacity: 0.8;">${fish.weight}kg</div>
            <div style="font-size: 0.85em; color: #4ade80;">💰 ${fish.value}g</div>
        `;
        inventoryGrid.appendChild(fishCard);
    });
}

function updateQuestUI() {
    document.getElementById('quest1Progress').textContent = `${gameState.dailyQuests.quest1.progress}/5`;
    document.getElementById('quest2Progress').textContent = `${gameState.dailyQuests.quest2.progress}/3`;
    document.getElementById('streakDisplay').textContent = `Streak: ${gameState.dailyQuests.streak} days 🔥`;
}

// ========================================
// TAB SWITCHING
// ========================================

function switchTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active from all tab buttons
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById(`${tabName}Tab`).classList.add('active');
    
    // Activate corresponding tab button
    event.target.classList.add('active');
}

// ========================================
// MESSAGE LOG
// ========================================

function addMessage(message) {
    const messageLog = document.getElementById('messageLog');
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message';
    messageDiv.textContent = message;
    messageLog.insertBefore(messageDiv, messageLog.firstChild);
    
    // Keep only last 20 messages
    while (messageLog.children.length > 20) {
        messageLog.removeChild(messageLog.lastChild);
    }
}

// ========================================
// SHOPS
// ========================================

function showShop(shopType) {
    if (shopType === 'rod') {
        addMessage("🎣 Rod Shop coming soon! Upgrade your fishing rod for better catches!");
    } else if (shopType === 'boat') {
        addMessage("⛵ Boat Shop coming soon! Buy boats to access new islands!");
    }
}

function showIslands() {
    addMessage("🏝️ Island travel coming soon! Explore 50+ unique islands!");
}

// ========================================
// FISHERMEN HIRING
// ========================================

function hireFisherman(fisherName) {
    if (gameState.hiredFishermen.length >= gameState.maxFishermen) {
        addMessage(`❌ You already have ${gameState.maxFishermen} fishermen hired!`);
        return;
    }
    
    const costs = {
        'oldpete': { hire: 50, daily: 5, name: 'Old Pete' },
        'youngmarcus': { hire: 75, daily: 8, name: 'Young Marcus' }
    };
    
    const cost = costs[fisherName];
    
    if (gameState.player.gold < cost.hire) {
        addMessage(`❌ Not enough gold! Need ${cost.hire}g to hire ${cost.name}.`);
        return;
    }
    
    gameState.player.gold -= cost.hire;
    gameState.hiredFishermen.push({
        id: fisherName,
        name: cost.name,
        dailyWage: cost.daily,
        catchTime: fisherName === 'oldpete' ? 7200000 : 6300000, // milliseconds
        lastCatch: Date.now(),
        catches: []
    });
    
    addMessage(`✅ Hired ${cost.name}! They will fish for you even when offline.`);
    updateStatsUI();
}

// ========================================
// SAVE/LOAD SYSTEM
// ========================================

function saveGame() {
    try {
        localStorage.setItem('fishingGameSave', JSON.stringify(gameState));
        localStorage.setItem('fishingGameSaveTime', Date.now());
        addMessage('💾 Game saved successfully!');
    } catch (error) {
        addMessage('❌ Error saving game: ' + error.message);
    }
}

function loadGame() {
    try {
        const savedData = localStorage.getItem('fishingGameSave');
        if (savedData) {
            const loadedState = JSON.parse(savedData);
            
            // Merge with current state to handle version updates
            Object.assign(gameState, loadedState);
            
            // Restore Set object
            gameState.discoveredFish = new Set(loadedState.discoveredFish || []);
            
            // Process offline fisherman catches
            processOfflineFishing();
            
            updateStatsUI();
            updateInventoryUI();
            updateQuestUI();
            addMessage('📂 Game loaded successfully!');
        } else {
            addMessage('❌ No saved game found!');
        }
    } catch (error) {
        addMessage('❌ Error loading game: ' + error.message);
    }
}

function processOfflineFishing() {
    const now = Date.now();
    const lastSave = localStorage.getItem('fishingGameSaveTime') || now;
    const timeAway = now - lastSave;
    
    if (timeAway < 60000) return; // Less than 1 minute, ignore
    
    gameState.hiredFishermen.forEach(fisherman => {
        const timePassedSinceLastCatch = now - fisherman.lastCatch;
        const catchesMade = Math.floor(timePassedSinceLastCatch / fisherman.catchTime);
        
        if (catchesMade > 0) {
            for (let i = 0; i < catchesMade; i++) {
                // Fishermen catch Uncommon to Legendary only
                const rarityRoll = Math.random() * 100;
                let rarity;
                if (rarityRoll < 60) rarity = 'uncommon';
                else if (rarityRoll < 90) rarity = 'rare';
                else if (rarityRoll < 98) rarity = 'epic';
                else rarity = 'legendary';
                
                const fishList = FISH_DATABASE[rarity];
                const fishName = fishList[Math.floor(Math.random() * fishList.length)];
                
                fisherman.catches.push({
                    name: fishName,
                    rarity: rarity,
                    value: rarity === 'uncommon' ? 15 : rarity === 'rare' ? 45 : rarity === 'epic' ? 150 : 750
                });
            }
            
            fisherman.lastCatch = now;
            addMessage(`💼 ${fisherman.name} caught ${catchesMade} fish while you were away!`);
        }
    });
}

// ========================================
// AUTO-SAVE
// ========================================

setInterval(() => {
    saveGame();
}, 60000); // Auto-save every 60 seconds

// ========================================
// INITIALIZE GAME
// ========================================

window.onload = function() {
    // Initialize sound system
    SoundSystem.init();
    
    // Setup mini-game controls with hold-down support
    let leftHeld = false;
    let rightHeld = false;
    let holdInterval = null;
    
    const startHoldLeft = () => {
        leftHeld = true;
        MiniGame.moveLeft();
        if (!holdInterval) {
            holdInterval = setInterval(() => {
                if (leftHeld) MiniGame.moveLeft();
                if (rightHeld) MiniGame.moveRight();
            }, 50); // Move every 50ms while holding
        }
    };
    
    const startHoldRight = () => {
        rightHeld = true;
        MiniGame.moveRight();
        if (!holdInterval) {
            holdInterval = setInterval(() => {
                if (leftHeld) MiniGame.moveLeft();
                if (rightHeld) MiniGame.moveRight();
            }, 50);
        }
    };
    
    const stopHold = () => {
        leftHeld = false;
        rightHeld = false;
        if (holdInterval) {
            clearInterval(holdInterval);
            holdInterval = null;
        }
    };
    
    // Mouse events
    document.getElementById('moveLeftBtn').addEventListener('mousedown', startHoldLeft);
    document.getElementById('moveRightBtn').addEventListener('mousedown', startHoldRight);
    document.addEventListener('mouseup', stopHold);
    
    // Touch events for mobile
    document.getElementById('moveLeftBtn').addEventListener('touchstart', (e) => {
        e.preventDefault();
        startHoldLeft();
    });
    
    document.getElementById('moveRightBtn').addEventListener('touchstart', (e) => {
        e.preventDefault();
        startHoldRight();
    });
    
    document.addEventListener('touchend', stopHold);
    
    updateStatsUI();
    updateInventoryUI();
    updateQuestUI();
    
    // Try to load saved game
    const savedData = localStorage.getItem('fishingGameSave');
    if (savedData) {
        const loadConfirm = confirm('Found saved game! Load it?');
        if (loadConfirm) {
            loadGame();
        }
    }
    
    addMessage('🌊 Welcome to Deep Sea Fishing Adventure!');
    addMessage('🎣 Cast your line to catch fish and level up!');
    addMessage('💡 Tip: Complete daily quests for bonus rewards!');
    addMessage('🔊 Sound effects enabled! Adjust volume in header.');
    addMessage('🎮 New! Interactive mini-game when fish bite!');
};

// Save before closing
window.onbeforeunload = function() {
    saveGame();
};
